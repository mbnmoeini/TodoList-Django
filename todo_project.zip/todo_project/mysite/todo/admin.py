from django.contrib import admin
from todo.models import ToDoItem

admin.site.register(ToDoItem)